package com.cg.bank.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.cg.bank.dto.Customer;



public class BankDaoImpl implements BankDao{
	
	EntityManager manager;
	
	public BankDaoImpl(){
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("JPA-PU");
		manager =emf.createEntityManager();
	}
	
	@Override
	public void createAccount(Customer customer){
		manager.getTransaction().begin();
		manager.persist(customer);
		manager.getTransaction().commit();	
		System.out.println("Customer added\nName: "+customer.getName()+"\nMobile number: "+customer.getMobileNo()+"\nAge: "+customer.getAge()+"\nBalance: "+customer.getInitialBalance());
	}

	@Override
	public void deposit(String mobileNo, double amount) {
		manager.getTransaction().begin();
		Customer cust = manager.find(Customer.class, mobileNo);
		double amt =cust.getInitialBalance();
		amt=amt+amount;
		cust.setInitialBalance(amt);
		manager.getTransaction().commit();
		System.out.println("Amount deposited! New balance: "+amt);
	}

	@Override
	public void withdraw(String mobileNo, double amount) {
		manager.getTransaction().begin();
		Customer cust = manager.find(Customer.class, mobileNo);
		double amt =cust.getInitialBalance();
		if(amt-amount>=500){
			amt=amt-amount;
			System.out.println(amt);
			cust.setInitialBalance(amt);
			manager.getTransaction().commit();
			System.out.println("Amount withdrawn! New balance: "+amt);
		}
		else{
			System.out.println("Cannot withdraw! Minimum balance of Rs.500 should be maintained");
		}
	}

	@Override
	public double checkBalance(String mobileNo) {
		Customer cust = manager.find(Customer.class, mobileNo);
		double amt =cust.getInitialBalance();
		System.out.println(amt);
		return amt;
		
	}

	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		manager.getTransaction().begin();
		Customer cust1 = manager.find(Customer.class, sender);
		double amt1 =cust1.getInitialBalance();
		Customer cust2 = manager.find(Customer.class, reciever);
		double amt2 =cust2.getInitialBalance();
		if(amt1-amount>=500){
			amt1=amt1-amount;
			amt2=amt2+amount;
			cust1.setInitialBalance(amt1);
			cust2.setInitialBalance(amt2);
			manager.getTransaction().commit();
			System.out.println("Amount transferred!\nNew balance in "+sender+" account is "+amt1+"\nBalance in "+reciever+" account is "+amt2);
		}
		else{
			System.out.println("Cannot tranfer! Sender has to maintain minimum balance of Rs.500");
		}
	}
	
	
	public boolean validateAccount(String mobileNo){
		Customer cust3=manager.find(Customer.class, mobileNo);
		if(cust3==null)
			return false;
		return true;
	}

}
